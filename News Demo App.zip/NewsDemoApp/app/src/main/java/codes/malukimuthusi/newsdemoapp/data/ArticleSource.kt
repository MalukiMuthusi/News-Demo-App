package codes.malukimuthusi.newsdemoapp.data

data class ArticleSource(
    val id: String?,
    val name: String
) {

}
