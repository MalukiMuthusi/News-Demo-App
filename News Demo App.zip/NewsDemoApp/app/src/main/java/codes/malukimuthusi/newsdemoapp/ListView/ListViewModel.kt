package codes.malukimuthusi.newsdemoapp.ListView

import androidx.lifecycle.ViewModel

class ListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
